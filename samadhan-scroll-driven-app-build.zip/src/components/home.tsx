"use client";

import { useState, type ReactNode } from "react";
import { AppShell } from "@/components/app/app-shell";
import { Toaster } from "@/components/app/toaster";
import { ScrollStage } from "@/components/scroll/scroll-stage";
import { SiteHeader } from "@/components/site-header";

// One website: the scroll story, then the working app, under one header.
export function Home(): ReactNode {
  const [idx, setIdx] = useState(0);
  return (
    <>
      <SiteHeader idx={idx} />
      <main>
        <ScrollStage onStateChange={setIdx} />
        <AppShell />
      </main>
      <Toaster />
    </>
  );
}

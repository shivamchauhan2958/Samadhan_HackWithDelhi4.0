"use client";

import { useRef, useState, type ReactNode } from "react";
import { notify } from "@/components/app/toaster";
import { useLang } from "@/components/lang-provider";
import { slaLine, escKey } from "@/components/app/live-map";
import { CategoryGlyph, TONE_VAR, toneLabelKey } from "@/components/ward/pin";
import { compressPhoto } from "@/lib/photo";
import { CATEGORIES, CATEGORY_META, derive, summarize, type ReportView } from "@/lib/ward";
import type { Key } from "@/lib/i18n";

// Dashboard: the ward's accountability numbers, plus the officer's triage list.
export function Dashboard({
  reports,
  now,
  officer,
  onToggleOfficer,
  onAssign,
  onResolve,
  onOpen,
  onReset,
  notifyReset,
}: {
  reports: ReportView[];
  now: number;
  officer: boolean;
  onToggleOfficer: () => void;
  onAssign: (id: string) => "ok" | "queued" | "rejected" | "missing";
  onResolve: (id: string, afterPhoto: string) => "ok" | "queued" | "rejected" | "missing";
  onOpen: (id: string) => void;
  onReset: () => Promise<boolean>;
  notifyReset: () => void;
}): ReactNode {
  const { t, lang } = useLang();
  const s = summarize(reports, now);
  const [resolveTarget, setResolveTarget] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const maxCat = Math.max(1, ...CATEGORIES.map((c) => s.byCategory[c]));

  const openList = reports
    .filter((r) => r.status !== "resolved")
    .map((r) => ({ r, d: derive(r, now) }))
    .sort((a, b) => Number(b.d.overdue) - Number(a.d.overdue) || b.d.score - a.d.score);

  const tiles: { label: string; value: string; note?: string }[] = [
    { label: t("dash.total"), value: String(s.total) },
    { label: t("dash.open"), value: String(s.open) },
    { label: t("dash.resolved"), value: String(s.resolved), note: s.awaiting > 0 ? `${s.awaiting} ${t("stats.awaiting")}` : undefined },
    { label: t("dash.fix"), value: `${s.avgFixDays.toFixed(1)} ${t("unit.days")}` },
    { label: t("dash.past"), value: String(s.pastDeadline) },
    { label: t("dash.escalated"), value: String(s.escalated) },
    { label: t("dash.reopened"), value: String(s.reopened) },
  ];

  const pickAfterPhoto = async (file: File | undefined) => {
    const id = resolveTarget;
    setResolveTarget(null);
    if (!file || !id) return;
    const data = await compressPhoto(file);
    if (!data) {
      notify(t("report.tooLarge"));
      return;
    }
    const result = onResolve(id, data);
    notify(result === "rejected" ? t("toast.needAfterPhoto") : result === "missing" ? t("error.generic") : t("toast.resolved"));
  };

  return (
    <div className="space-y-12">
      <div className="flex flex-wrap items-center justify-between gap-6 border-b border-[var(--rule)] pb-6">
        <p className="max-w-xl text-[var(--ink-soft)]">{t("dash.officerHint")}</p>
        <button
          type="button"
          role="switch"
          aria-checked={officer}
          onClick={onToggleOfficer}
          className="flex min-h-11 items-center gap-3 font-bold text-[var(--ink)]"
        >
          <span className="relative inline-block h-7 w-12 border-2 border-[var(--ink)] bg-[var(--surface)]" aria-hidden="true">
            <span
              className={`absolute top-[2px] h-[18px] w-[18px] bg-[var(--ink)] transition-transform duration-200 ${
                officer ? "translate-x-[22px]" : "translate-x-[2px]"
              }`}
            />
          </span>
          <span>{t("peak.officer")}</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-x-6 gap-y-8 md:grid-cols-4 lg:grid-cols-7">
        {tiles.map((tile) => (
          <div key={tile.label} className="border-t-2 border-[var(--ink)] pt-3">
            <p className="kicker">{tile.label}</p>
            <p className="num mt-2 text-3xl font-bold text-[var(--ink)]">{tile.value}</p>
            {tile.note && <p className="mt-1 text-[11px] text-[var(--ink-mute)]">{tile.note}</p>}
          </div>
        ))}
      </div>

      <div className="grid gap-12 lg:grid-cols-2">
        <section aria-labelledby="by-category">
          <h3 id="by-category" className="text-lg font-bold text-[var(--ink)]">
            {t("dash.byCategory")}
          </h3>
          <ul className="mt-6 space-y-5">
            {CATEGORIES.map((c) => {
              const n = s.byCategory[c];
              return (
                <li key={c} className="grid grid-cols-[minmax(0,10rem)_1fr_2.5rem] items-center gap-4">
                  <span className="flex items-center gap-2 text-sm font-bold text-[var(--ink)]">
                    <svg viewBox="4 2.5 24 24" width="20" height="20" aria-hidden="true">
                      <CategoryGlyph category={c} />
                    </svg>
                    {CATEGORY_META[c][lang]}
                  </span>
                  <span className="h-4 bg-[var(--rule)]" aria-hidden="true">
                    <span className="block h-full bg-[var(--ink)]" style={{ width: `${(n / maxCat) * 100}%` }} />
                  </span>
                  <span className="num text-right text-sm font-bold text-[var(--ink)]">{n}</span>
                </li>
              );
            })}
          </ul>
        </section>

        <section aria-labelledby="open-list">
          <h3 id="open-list" className="text-lg font-bold text-[var(--ink)]">
            {t("dash.list")}
          </h3>
          <ul className="mt-6 divide-y divide-[var(--rule)] border-y border-[var(--rule)]">
            {openList.length === 0 && <li className="py-4 text-sm text-[var(--ink-soft)]">{t("dash.empty")}</li>}
            {openList.slice(0, 12).map(({ r, d }) => (
              <li key={r.id} className="flex flex-wrap items-center gap-3 py-3">
                <button type="button" onClick={() => onOpen(r.id)} className="flex min-h-11 min-w-0 flex-1 items-center gap-3 text-left">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold text-[var(--ink)]">
                      {CATEGORY_META[r.category][lang]} · <span className="num">{r.id}</span>
                    </span>
                    <span className="block text-xs text-[var(--ink-mute)]">
                      {t(`stage.${r.status}` as Key)} · {slaLine(r, now, t)}
                    </span>
                  </span>
                  <span className="inline-flex shrink-0 flex-wrap items-center gap-1.5">
                    <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[var(--ink)]">
                      <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: TONE_VAR[d.tone] }} aria-hidden="true" />
                      {t(toneLabelKey(d.tone))} <span className="num">{d.score}</span>
                    </span>
                    {d.escalation !== "none" && (
                      <span className="badge-esc" data-level="high">
                        {t(escKey(d.escalation))}
                      </span>
                    )}
                  </span>
                </button>
                {officer && r.status === "verified" && (
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => {
                      const result = onAssign(r.id);
                      notify(result === "rejected" ? t("toast.needVerify") : result === "missing" ? t("error.generic") : t("toast.assigned"));
                    }}
                  >
                    {t("detail.advance")}
                  </button>
                )}
                {officer && r.status === "assigned" && (
                  <>
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      className="sr-only"
                      tabIndex={-1}
                      onChange={(e) => {
                        void pickAfterPhoto(e.target.files?.[0]);
                        e.target.value = "";
                      }}
                    />
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => {
                        setResolveTarget(r.id);
                        fileRef.current?.click();
                      }}
                    >
                      {t("detail.resolve")}
                    </button>
                  </>
                )}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={async () => {
            await onReset();
            notifyReset();
          }}
        >
          {t("dash.reset")}
        </button>
      </div>
    </div>
  );
}

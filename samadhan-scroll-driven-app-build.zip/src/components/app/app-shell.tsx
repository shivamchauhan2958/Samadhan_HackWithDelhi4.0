"use client";

import { useEffect, useState, type ReactNode } from "react";
import { Dashboard } from "@/components/app/dashboard";
import { LiveMap } from "@/components/app/live-map";
import { ReportForm } from "@/components/app/report-form";
import { SmsInbox } from "@/components/app/sms-inbox";
import { notify } from "@/components/app/toaster";
import { useReports } from "@/components/app/use-reports";
import { useLang } from "@/components/lang-provider";
import type { Key } from "@/lib/i18n";
import { KEYS, readString, writeString } from "@/lib/storage";

type Tab = "live" | "report" | "dashboard" | "sms";
const TABS: { id: Tab; label: Key; hash: string }[] = [
  { id: "live", label: "nav.live", hash: "#live-map" },
  { id: "report", label: "nav.report", hash: "#report" },
  { id: "dashboard", label: "nav.dashboard", hash: "#dashboard" },
  { id: "sms", label: "nav.sms", hash: "#sms" },
];

// The working app below State 06: four tabs over one shared, offline-first store.
export function AppShell(): ReactNode {
  const { t } = useLang();
  const data = useReports();
  const [tab, setTab] = useState<Tab>("live");
  const [officer, setOfficer] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    const savedOfficer = readString(KEYS.officer) === "1";
    const restore = window.setTimeout(() => {
      setOfficer(savedOfficer);
      setNow(Date.now());
    }, 0);
    const tick = window.setInterval(() => setNow(Date.now()), 60_000);
    const openFromHash = () => {
      const match = TABS.find((x) => x.hash === window.location.hash);
      if (!match) return;
      setTab(match.id);
      window.requestAnimationFrame(() => document.getElementById("app")?.scrollIntoView({ block: "start" }));
    };
    openFromHash();
    window.addEventListener("hashchange", openFromHash);
    return () => {
      window.clearTimeout(restore);
      window.clearInterval(tick);
      window.removeEventListener("hashchange", openFromHash);
    };
  }, []);

  const toggleOfficer = () => {
    const next = !officer;
    setOfficer(next);
    writeString(KEYS.officer, next ? "1" : "0");
  };

  const selectTab = (next: Tab) => {
    setTab(next);
    const hash = TABS.find((x) => x.id === next)?.hash ?? "";
    window.history.replaceState(null, "", hash);
  };

  const openReport = (id: string) => {
    setSelectedId(id);
    selectTab("live");
  };

  const ready = data.ready && now !== null;
  const statusLine = data.sync === "offline" ? t("app.offline") : data.sync === "live" ? t("app.synced") : t("app.loading");
  const pendingLine = data.pendingCount > 0 ? ` · ${t("app.pending", { n: data.pendingCount })}` : "";

  return (
    <section id="app" className="border-t-2 border-[var(--ink)] px-4 pb-20 pt-12 md:px-8 md:pt-16">
      <div className="mx-auto max-w-[1280px]">
        <div className="flex flex-wrap items-end justify-between gap-6 border-b border-[var(--rule)] pb-6">
          <div>
            <p className="kicker">{t("app.eyebrow")}</p>
            <h2 className="display-sm mt-2">{t("app.title")}</h2>
            <p className="num mt-2 text-sm text-[var(--ink-soft)]" role="status">
              {statusLine}
              {pendingLine}
            </p>
          </div>
          <div role="tablist" aria-label={t("app.tabs")} className="flex flex-wrap gap-2">
            {TABS.map((item) => {
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  id={`tab-${item.id}`}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  aria-controls="app-panel"
                  onClick={() => selectTab(item.id)}
                  className={`btn btn-sm md:min-h-12 ${active ? "btn-primary" : "btn-ghost"}`}
                >
                  {t(item.label)}
                </button>
              );
            })}
          </div>
        </div>

        <div id="app-panel" role="tabpanel" aria-labelledby={`tab-${tab}`} className="mt-8">
          {!ready ? (
            <p className="text-[var(--ink-soft)]">{t("app.loading")}</p>
          ) : tab === "live" ? (
            <LiveMap
              reports={data.reports}
              events={data.events}
              now={now ?? 0}
              officer={officer}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onVote={data.vote}
              onAssign={data.assign}
              onResolve={data.resolve}
              onConfirm={data.confirm}
              onReopen={data.reopen}
            />
          ) : tab === "report" ? (
            <ReportForm reports={data.reports} onCreate={data.create} onVote={data.vote} onDone={openReport} />
          ) : tab === "dashboard" ? (
            <Dashboard
              reports={data.reports}
              now={now ?? 0}
              officer={officer}
              onToggleOfficer={toggleOfficer}
              onAssign={data.assign}
              onResolve={data.resolve}
              onOpen={openReport}
              onReset={data.reset}
              notifyReset={() => notify(t("dash.resetDone"))}
            />
          ) : (
            <SmsInbox reports={data.reports} events={data.events} />
          )}
        </div>
      </div>
    </section>
  );
}

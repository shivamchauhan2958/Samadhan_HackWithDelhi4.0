import { ApiError, createReport, listReports } from "@/lib/server/reports";

export const dynamic = "force-dynamic";

function fail(err: unknown) {
  if (err instanceof ApiError) {
    return Response.json({ error: err.message, ...(err.extra ?? {}) }, { status: err.status });
  }
  console.error("[api/reports]", err);
  return Response.json({ error: "Database unavailable" }, { status: 503 });
}

export async function GET() {
  try {
    const data = await listReports();
    return Response.json({ ...data, serverTime: new Date().toISOString() }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    return fail(err);
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body) throw new ApiError(400, "Invalid JSON");
    const { report } = await createReport({
      id: body.id,
      category: body.category,
      x: body.x,
      y: body.y,
      description: body.description,
      photo: body.photo,
    });
    return Response.json({ report }, { status: 201 });
  } catch (err) {
    return fail(err);
  }
}
